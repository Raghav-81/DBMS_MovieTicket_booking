require("dotenv").config();
const express = require("express");
const app = express();

const cors = require("cors");
const morgan = require("morgan");
const db = require("./db");

//middleware
app.use(cors());

app.use(express.json());

//ROUTES//

//Customer name to Customer
//Movie name to mpovie
//# of tickets to Ticket
//ticket cost from Ticket 


//Get all tickets

app.get("/api/v1/tickets", async (req, res) => {
    
    try {

        const results = await db.query("SELECT * FROM Ticket_info");
        

        res.status(200).json({
            status: "Success",
            results: results.rows.length,
            data: {

                t_info: results.rows,

            },

        });

    } catch(err) {
        console.error(err);

    }
    
    
    
});


//Create a Ticket

app.post("/api/v1/tickets", async (req, res) => {
    console.log(req.body);
    try{

        const results = await db.query(
            "INSERT INTO Ticket_info (t_id, c_name, m_name, cost) VALUES (DEFAULT, $1, $2, $3) RETURNING *",
            [req.body.c_name, req.body.m_name, req.body.cost]
        );        
        
        console.log(results);

        res.status(201).json({

            status: "Success",
            data:{
                Ticket_details: results.rows[0],

            },
            

        });

    }catch(err){
        console.error(err);
    }
});




const port = process.env.PORT || 5000;
app.listen(port, () => {
    console.log(`Server has started on port ${port}`);
});