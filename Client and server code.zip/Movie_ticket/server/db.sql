drop database movie;
CREATE database movie;

\c movie

CREATE Table Ticket_info
(
  t_id SERIAL PRIMARY KEY,
  c_name VARCHAR(20) NOT NULL,
  m_name VARCHAR(50) NOT NULL,
  cost INT NOT NULL
);

INSERT INTO Ticket_info (t_id, c_name, m_name, cost) VALUES (1, 'Raghav', 'MIB', 400); 