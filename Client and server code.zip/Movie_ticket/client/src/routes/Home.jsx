import React from 'react'
import {Header} from "../Components/Header";
import {NewTicket} from "../Components/NewTicket";
import {TicketList} from "../Components/TicketList";


const Home = () => {
    return(
        <div>
            <Header />
            <NewTicket />
            <TicketList />
        </div>

    );

};
    
     
export default Home;     
