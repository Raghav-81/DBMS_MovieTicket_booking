import React from 'react'

export const Header = () => {
    return (
        <div>
            <h1 className = "font-weight-light display-1 text-center">Movie Ticket Booking</h1>
        </div>
    )
}
