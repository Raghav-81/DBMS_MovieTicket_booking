import React from 'react'
import BookingTickets from '../apis/BookingTickets';

export const NewTicket = () => {
    const [c_name, setC_name] = React.useState("")
    const [m_name, setM_name] = React.useState("")
    const [cost, setCost] = React.useState("")


    const handleSubmit = (e) => {
        e.preventDefault();
        const data = {
            c_name,
            m_name,
            cost
        };

        BookingTickets.post("/", data)
        .then(res => {
            window.location.reload();
        }).catch(err => {
            console.log(err);
        }) 
    }

    return (
        <div className="input-group mb-3">
            <form onSubmit={handleSubmit}>
                <div className="input-group mb-3">

                    <span className="input-group-text" id="basic-addon1">  </span>
                    <input type="text" className="form-control" placeholder="Name" aria-label="Name" size="50" value={c_name} onChange={e => setC_name(e.target.value)}/>

                    <span className="input-group-text" id="basic-addon1">  </span>
                    <input type="text" className="form-control" placeholder="Movie Name" aria-label="Movie" size="50" value={m_name} onChange={e => setM_name(e.target.value)}/>

                    <span className="input-group-text" id="basic-addon1">  </span>
                    <input type="text" className="form-control" placeholder="Cost" aria-label="Cost" size="50" value={cost} onChange={e => setCost(e.target.value)}/>

                    <button className="btn btn-primary">Book</button>
                    
                </div>

            </form>
            
        </div>
    )
}
