import React, {useEffect} from 'react';
import BookingTickets from '../apis/BookingTickets';


export const TicketList = (props) => {

    const [tickets, setTickets] = React.useState([]);

    useEffect(() => {               
                
        BookingTickets.get("/")
        .then((res) => {
            setTickets(res.data.data.t_info);

        }).catch((err) => {
            console.log(err);
        });              
           
        

    }, []);

    return (
        <div>
            <table className="table table-hover">
                <thead>
                    <tr>
                    <th scope="col">#</th>
                    <th scope="col">Customer Name</th>
                    <th scope="col">Movie Name</th>
                    <th scope="col">Cost</th>
                    </tr>
                </thead>
                <tbody>
                    {tickets.map(ticket => (
                        <tr key={ticket.t_id}>
                            <th scope="row">{ticket.t_id}</th>
                            <td>{ticket.c_name}</td>
                            <td>{ticket.m_name}</td>
                            <td>{ticket.cost}</td>
                        </tr>
                    ))}
                    
                    
                    
    
                </tbody>
            </table>
        </div>
    )
}
